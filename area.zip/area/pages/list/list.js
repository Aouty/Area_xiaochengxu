// pages/list/list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    /**aouty:从后台获取的数据存放在list中 */
    list: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    /**aouty:此方法仅仅加载页面，并不会更新页面数据 */
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    /**aouty:这个方法会显示最新数据 */
    /**aouty:访问后台获取数据 */
    var that = this;/**aouty:this表示当前对象，哪个方法执行就是谁*/
    /**aouty:微信请求 */
    wx.request({
      url: 'http://localhost:8082/demo/superadmin/listarea',
      method: 'GET',
      data: {},/**data表示传入的参数，此处不需要传入任何参数 */
      success: function (res) {
        var listarea = res.data.areaList;
        if (listarea == null) {
          /**aouty:在界面显示错误提示信息 */
          var toastText = '获取数据失败：' + res.data.errMsg;
          wx.showToast({
            title: toastText,
            icon: '',/**图标不需要设置 */
            duration: 10000/**持续时间，信息显示的时间 */
          });
        } else {
          that.setData({
            list: listarea
          });
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * aouty:添加区域信息
   */
  addArea: function () {
    wx.navigateTo({
      /** '..'表示返回到上一级目录 */
      url: '../operation/operation',
    });
  },
  /**
   * aouty:删除区域
   * 1.确定删除?  2.根据id删除   3.删除之后更新list
   */
  deleteArea: function (e) {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定要删除[' + e.target.dataset.areaname + ']吗？',
      success: function (sm) {
        if (sm.confirm) {
          wx.request({
            url: 'http://127.0.0.1:8082/demo/superadmin/removearea',
            /**e.target.dataset.areaid中areaid与list.xml中的data-areaid的areaid相对应 */
            data: { "areaId": e.target.dataset.areaid },
            method: 'GET',
            success: function (res) {
              var result = res.data.success;
              var toastText = "删除成功!";
              if (result != true) {
                toastText = "删除失败！";
              } else {
                that.data.list.splice(e.target.dataset.index, 1);
                that.setData({
                  list: that.data.list
                });
              }
              wx.showToast({
                title: toastText,
                icon: '',
                duration: 2000
              })
            }
          });
        }
      }
    });
  }
})